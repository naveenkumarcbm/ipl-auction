export interface players{
    name:String;
    batting:number;
    bowling:number;
    allRounder:number;
    price:number;
}